# blog-css-js

Laravel 5.1的blog教程的css和js静态文件。

```
git clone https://github.com/JellyBool/blog-css-js.git

```

这样之后直接将css/ ，js/ 和 fonts/ 文件夹拷贝到 public/文件夹之下
